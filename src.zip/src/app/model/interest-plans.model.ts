export class InterestPlans{
    plan:String='';
    rate: number=0;

}