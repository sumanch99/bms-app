export class Account{
    accNo: number=2;
	accType: string='';
	balance: number=0;
	active: boolean=false;
	ifscCode: string='';
	adhaarNumber:string='';
	phoneNumber: string='';
	introducerAccountNo: number=0;
	nomineeAdhaarNo: string='';
	constructor()
	{

	}
}