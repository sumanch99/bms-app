import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-my-accounts',
  templateUrl: './customer-my-accounts.component.html',
  styleUrls: ['./customer-my-accounts.component.css']
})
export class CustomerMyAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
