export class Transaction 
{
    fromAccount:number =0;
	toAccount:number=0;
	amount:number=0;
	date:Date=new Date();
	flag:boolean=false;
	atmFlag:boolean=false;
}