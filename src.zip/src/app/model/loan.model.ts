export class Loan{
    loan_id:number=0;
    loanCode:string='';
    accNo:number=0;
    amount:number=0;
	gurantorAccNo:number=0;
    tenure:number=0;
	startDate:Date=new Date();
	approved:boolean=false;

}