export class Admin
{
	empId=0;
	password='';
	phoneNo ='';
	adhaarNo='';
    constructor()
    {
        
    }
}