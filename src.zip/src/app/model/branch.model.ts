export class Branch
{
     //ifscCode:string = ''
	 //branchName:string = ''
	 //address:string = ''
	 //pincode:number = 0
	 //branchFund:number = 0
	 constructor(public ifscCode:string,public branchName:string,public address:string,public pincode:number,public branchFund:number)
	 {
		 
	 }
}